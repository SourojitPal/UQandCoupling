# TRIAD-UQ — reference implementation (v0.2, Rev.2 plan)

Three-term uncertainty decomposition (Aleatoric / Epistemic / Distributional)
with the **Coupling** interaction term, plus the machinery that turns the
identity from a tautology into a **testable, recoverable** relationship.

This code implements the Rev.2 code plan. The guiding rule (plan §2.2):

> Closure of `Total = Aleatoric + Epistemic + Distributional − Coupling` is an
> **algebraic identity** when all six terms come from one joint. Verifying it is
> a **code-correctness gate**, not evidence. The evidence lives in the
> independent instruments, the controls, and the hypotheses.

## What runs where

| Part | Needs data? | Status |
|---|---|---|
| `tests/test_sanity.py` | no | **runs anywhere** — the estimator-validation harness (XOR ⇒ Coupling < 0, redundant ⇒ Coupling > 0, closure ≈ 1e-12) |
| `run_demo.py` | no | **runs anywhere** — full pipeline on synthetic two-domain data (plumbing only, not reported) |
| `triad_uq/pipeline.py` | yes (UCI) | run on your machine once the four sites are available |

## Install & verify

```bash
pip install -r requirements.txt
python tests/test_sanity.py          # must print: All estimator-validation checks passed.
python run_demo.py                    # end-to-end plumbing on synthetic data
```

## Getting the real data (no synthetic shift in the reported experiment)

UCI Heart Disease, four sites on one shared schema. Either:

- `pip install ucimlrepo` (fetches when run locally), **or**
- drop the classic processed files in `data/` as `cleveland.csv`, `hungarian.csv`,
  `switzerland.csv`, `va.csv` (comma-separated, `?` = missing, last column = target).

Then:

```python
from triad_uq.data import load_sites
from triad_uq.pipeline import run_pair
sites = load_sites(data_dir="data/")
res = run_pair(sites["cleveland"], sites["hungarian"], seed=0,
               pair_name="cleveland->hungarian")
print(res["closure_max_residual"], res["controls"], res["H3"])
res["long_table"].to_csv("cleveland_hungarian_terms.csv", index=False)
```

## Module map (plan §5)

- `info.py` — entropy / MI / I_min PID / **`decompose_from_joint`** (the six terms).
- `joint_grid.py` — build P(y, k, z) from the two-regime ensemble grid; `decompose_point`, `decompose_set`.
- `independent_bank.py` — route-B instruments: MMD, proxy A-distance, nats-scale domain-MI (Distributional, STRONG independence); predictive variance (Epistemic, WEAK); kNN aleatoric proxy.
- `controls.py` — permute-Z null and no-shift positive control (§3.3), **report these first**.
- `synthetic.py` + `tests/` — estimator validation only (§9).
- `data.py` / `models.py` / `interventions.py` — sites & splits; bagged ensemble + domain classifier; baseline / fine-tune-self-train / BALD active learning.
- `hypotheses.py` — H1 regime, H2 specificity, **H3 (headline, magnitude-first, out-of-sample, cross-intervention)**, H4 diagnostic, **H5 recovery** (LOTO on Distributional).
- `pipeline.py` — orchestrates one pair → long table + control/hypothesis summaries.

## Implementation notes

- **Keep member probabilities soft.** Unregularized RF trees are near-deterministic,
  which drives Aleatoric to ≈ 0. `config.yaml` sets `min_samples_leaf: 5`; tune it
  so members produce calibrated soft probabilities.
- **Units are nats** throughout.
- **Redundancy** uses I_min with defensive clipping to keep PID atoms non-negative;
  `frac_clipped` is logged. Cross-check with I_ccs (Ince) is a TODO stub in the plan (§3.1).
- **H3 is magnitude-first.** If Coupling never changes sign (H1: redundancy-dominated),
  the *sign* version of H3 is vacuous — hunt negative-Coupling points (high-shift pairs,
  second disease) as the plan warns (§7).

## Priority order (plan §12)

- **P0:** sanity harness ✓, controls ✓, MMD/A-distance instrument ✓, H3 ✓ — done here.
- **P1:** numerical LOTO recovery (H5) ✓ scaffolded; Ben-David correspondence — `analysis/` TODO.
- **P2:** full route-B bank for all four terms; I_ccs cross-check; second-disease cohort; leave-one-site-out.
