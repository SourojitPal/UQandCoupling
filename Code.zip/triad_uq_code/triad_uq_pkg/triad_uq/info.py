"""
Core information-theoretic estimators for TRIAD-UQ.

Everything is derived from a single joint distribution P(y, s1, s2) per test
point, where s1 indexes the theta-axis (ensemble member) and s2 indexes the
Z-axis (source vs target-adapted regime). Building the joint once and deriving
all six terms from it is what makes the estimators mutually consistent
(Rev.2 plan, section 2). Units are nats (natural log).

NOTE ON EVIDENCE (Rev.2 plan, section 2.2): the closure of the identity
    Total = Aleatoric + Epistemic + Distributional - Coupling
is an ALGEBRAIC IDENTITY here. `decompose_from_joint` returns `residual`,
which should be ~0 for every joint. That is a CODE-CORRECTNESS GATE, not
evidence about data. The evidence comes from the independent instruments
(independent_bank.py), the controls (controls.py) and the hypotheses
(hypotheses.py).
"""
from __future__ import annotations
import numpy as np

EPS = 1e-12


def entropy(p: np.ndarray, axis: int = -1) -> np.ndarray:
    """Shannon entropy in nats along `axis`, with 0*log0 = 0."""
    p = np.asarray(p, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        terms = np.where(p > EPS, -p * np.log(p), 0.0)
    return terms.sum(axis=axis)


def mi_from_joint2(Pab: np.ndarray) -> float:
    """Mutual information I(A;B) in nats from a 2-D joint P(a,b) (sums to 1)."""
    Pab = np.asarray(Pab, dtype=float)
    Pab = Pab / Pab.sum()
    Pa = Pab.sum(axis=1, keepdims=True)
    Pb = Pab.sum(axis=0, keepdims=True)
    denom = Pa * Pb
    with np.errstate(divide="ignore", invalid="ignore"):
        terms = np.where(Pab > EPS, Pab * np.log(Pab / denom), 0.0)
    return float(terms.sum())


def _specific_information(Py_s: np.ndarray, py: np.ndarray, ps: np.ndarray) -> np.ndarray:
    """
    Williams & Beer specific information I(Y=y ; S) for every y.
    Py_s : joint P(y, s)  [ny, ns]
    py   : marginal P(y)  [ny]
    ps   : marginal P(s)  [ns]
    Returns array [ny].
    """
    with np.errstate(divide="ignore", invalid="ignore"):
        p_s_given_y = np.where(py[:, None] > EPS, Py_s / py[:, None], 0.0)
        p_y_given_s = np.where(ps[None, :] > EPS, Py_s / ps[None, :], 0.0)
        ratio = np.where(py[:, None] > EPS, p_y_given_s / py[:, None], 0.0)
        logratio = np.where(ratio > EPS, np.log(ratio), 0.0)
        terms = np.where(Py_s > EPS, p_s_given_y * logratio, 0.0)
    return terms.sum(axis=1)


def redundancy_imin(P: np.ndarray, clip: bool = True):
    """
    I_min redundancy (Williams & Beer, 2010) of sources {s1, s2} about y,
    from the joint P(y, s1, s2).

    Returns (R, n_clipped). If clip=True, R is clamped to
    [0, min(I(y;s1), I(y;s2))] so the PID atoms stay non-negative; n_clipped
    reports whether the raw value fell outside that range (a diagnostic, not
    something to hide -- see Rev.2 plan section 10).
    """
    P = np.asarray(P, dtype=float)
    P = P / P.sum()
    py = P.sum(axis=(1, 2))
    Py_s1 = P.sum(axis=2)          # [ny, n1]
    Py_s2 = P.sum(axis=1)          # [ny, n2]
    ps1 = Py_s1.sum(axis=0)
    ps2 = Py_s2.sum(axis=0)

    spec1 = _specific_information(Py_s1, py, ps1)
    spec2 = _specific_information(Py_s2, py, ps2)
    R = float((py * np.minimum(spec1, spec2)).sum())

    n_clipped = 0
    if clip:
        i1 = mi_from_joint2(Py_s1)
        i2 = mi_from_joint2(Py_s2)
        hi = max(0.0, min(i1, i2))
        R_clipped = min(max(R, 0.0), hi)
        if abs(R_clipped - R) > 1e-9:
            n_clipped = 1
        R = R_clipped
    return R, n_clipped


def decompose_from_joint(P: np.ndarray, clip: bool = True) -> dict:
    """
    Full six-term decomposition + PID atoms from a joint P(y, s1, s2).

    Returns a dict with:
      total, aleatoric, i_ykz, epistemic, distributional, coupling,
      redundancy, unique_theta, unique_z, synergy, residual, n_clipped
    """
    P = np.asarray(P, dtype=float)
    P = P / P.sum()

    py = P.sum(axis=(1, 2))
    total = float(entropy(py))

    w = P.sum(axis=0)                                  # [n1, n2] weight of each (s1,s2)
    with np.errstate(divide="ignore", invalid="ignore"):
        cond = np.where(w[None, :, :] > EPS, P / w[None, :, :], 0.0)  # p(y|s1,s2)
    H_cond = entropy(cond, axis=0)                     # [n1, n2]
    aleatoric = float((w * H_cond).sum())

    i_ykz = total - aleatoric                          # I(y; s1, s2)

    epistemic = mi_from_joint2(P.sum(axis=2))          # I(y; s1)  (theta)
    distributional = mi_from_joint2(P.sum(axis=1))     # I(y; s2)  (Z)
    coupling = epistemic + distributional - i_ykz      # interaction information

    R, n_clipped = redundancy_imin(P, clip=clip)
    unique_theta = epistemic - R
    unique_z = distributional - R
    synergy = i_ykz - unique_theta - unique_z - R

    residual = total - (aleatoric + epistemic + distributional - coupling)

    return dict(
        total=total, aleatoric=aleatoric, i_ykz=i_ykz,
        epistemic=epistemic, distributional=distributional, coupling=coupling,
        redundancy=R, unique_theta=unique_theta, unique_z=unique_z,
        synergy=synergy, residual=float(residual), n_clipped=n_clipped,
    )


def perplexity_form(terms: dict) -> dict:
    """Multiplicative (perplexity-space) view, PPL(x)=exp(x) -- Rev.2 plan / addendum 1.4.6."""
    return {
        "ppl_total": float(np.exp(terms["total"])),
        "ppl_aleatoric": float(np.exp(terms["aleatoric"])),
        "ppl_epistemic": float(np.exp(terms["epistemic"])),
        "ppl_distributional": float(np.exp(terms["distributional"])),
        "ppl_coupling": float(np.exp(terms["coupling"])),
    }
