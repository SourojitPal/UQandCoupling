"""
Build the per-point joint P(y, k, z) from the two-regime ensemble grid and
run the six-term decomposition (Rev.2 plan section 2.1).

  P_S : [K, C]  source-only ensemble member class-probabilities at x*
  P_T : [K, C]  target-adapted ensemble member class-probabilities at x*
  pi  : scalar  domain classifier P(in-domain) for x*   (omega_S = pi)

Weights: w[k, z] = (1/K) * omega_z, with omega_S = pi, omega_T = 1 - pi.
So P(y, k, z) = w[k, z] * p_{k,z}(y). k indexes theta, z indexes Z.
"""
from __future__ import annotations
import numpy as np
from .info import decompose_from_joint


def build_joint(P_S: np.ndarray, P_T: np.ndarray, pi: float) -> np.ndarray:
    """Return joint P of shape [C, K, 2] (y, k, z), summing to 1."""
    P_S = np.asarray(P_S, dtype=float)
    P_T = np.asarray(P_T, dtype=float)
    assert P_S.shape == P_T.shape, "source and target grids must match shape"
    K, C = P_S.shape
    pi = float(np.clip(pi, 0.0, 1.0))

    P = np.zeros((C, K, 2), dtype=float)
    P[:, :, 0] = (pi / K) * P_S.T          # z = source
    P[:, :, 1] = ((1.0 - pi) / K) * P_T.T  # z = target-adapted
    return P


def decompose_point(P_S: np.ndarray, P_T: np.ndarray, pi: float,
                    clip: bool = True) -> dict:
    """Six-term decomposition + PID atoms for a single test point."""
    P = build_joint(P_S, P_T, pi)
    return decompose_from_joint(P, clip=clip)


def decompose_set(P_S_all: np.ndarray, P_T_all: np.ndarray, pi_all: np.ndarray,
                  clip: bool = True) -> dict:
    """
    Vectorized-over-points wrapper.
      P_S_all, P_T_all : [N, K, C]
      pi_all           : [N]
    Returns dict of arrays [N] for each term, plus max_abs_residual (the
    correctness gate: should be ~1e-12).
    """
    N = P_S_all.shape[0]
    keys = ["total", "aleatoric", "i_ykz", "epistemic", "distributional",
            "coupling", "redundancy", "unique_theta", "unique_z", "synergy",
            "residual", "n_clipped"]
    out = {k: np.zeros(N) for k in keys}
    for i in range(N):
        d = decompose_point(P_S_all[i], P_T_all[i], float(pi_all[i]), clip=clip)
        for k in keys:
            out[k][i] = d[k]
    out["max_abs_residual"] = float(np.max(np.abs(out["residual"])))
    out["frac_clipped"] = float(np.mean(out["n_clipped"]))
    return out
