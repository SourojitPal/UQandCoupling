"""TRIAD-UQ: three-term uncertainty decomposition + Coupling, with an explicit
route from identity to evidence (Rev.2 plan)."""
from .info import decompose_from_joint, redundancy_imin, entropy, mi_from_joint2
from .joint_grid import decompose_point, decompose_set, build_joint

__all__ = ["decompose_from_joint", "redundancy_imin", "entropy",
           "mi_from_joint2", "decompose_point", "decompose_set", "build_joint"]
__version__ = "0.2.0"
