"""
Consistent, paper-grade figure styling for every TRIAD-UQ plot.

Requirements enforced here:
  * Times New Roman for titles, axis labels and tick labels. The font stack
    lists "Times New Roman" first (used on Windows / any machine that has it)
    and falls back to metric-compatible serifs (Liberation Serif / Nimbus /
    DejaVu Serif) elsewhere, so the layout is identical either way.
  * Minimum font sizes: axes title 20 pt, figure title (suptitle) 20 pt,
    axis labels 16 pt (ticks 14 pt, legend 14 pt).
  * Vector-friendly output so figures stay crisp at any zoom: TrueType fonts
    are embedded in PDF/PS (fonttype 42) and left as text in SVG. Call
    `save_vector(fig, path_without_ext)` to write a 300-dpi PNG *and* a vector
    PDF of the same figure.
"""
from __future__ import annotations
import logging
import matplotlib as mpl

_SERIF_STACK = ["Times New Roman", "Times", "Nimbus Roman",
                "Liberation Serif", "DejaVu Serif"]

_RC = {
    "font.family": "serif",
    "font.serif": _SERIF_STACK,
    "mathtext.fontset": "stix",        # serif-style math to match Times
    "axes.titlesize": 20,              # axes titles  >= 20 pt (increased from 16)
    "axes.labelsize": 16,              # axis labels   >= 16 pt (increased from 14)
    "figure.titlesize": 20,            # suptitle      >= 20 pt (increased from 16)
    "xtick.labelsize": 14,             # increased from 12
    "ytick.labelsize": 14,             # increased from 12
    "legend.fontsize": 14,             # increased from 12
    "legend.title_fontsize": 14,       # increased from 12
    "axes.titleweight": "normal",
    "figure.dpi": 120,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "pdf.fonttype": 42,                # embed TrueType -> scalable, selectable
    "ps.fonttype": 42,
    "svg.fonttype": "none",
}

_applied = False


def apply_style(force: bool = False) -> None:
    """Apply the TRIAD-UQ matplotlib style (idempotent)."""
    global _applied
    if _applied and not force:
        return
    mpl.rcParams.update(_RC)
    # keep the notebook clean if the exact 'Times New Roman' file is absent
    logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
    _applied = True


def save_vector(fig, path_no_ext: str, dpi: int = 300):
    """
    Save `fig` as BOTH a high-res PNG (readable when zoomed out) and a vector
    PDF (no pixelation when zoomed in). Returns (png_path, pdf_path).
    """
    apply_style()
    png, pdf = f"{path_no_ext}.png", f"{path_no_ext}.pdf"
    fig.savefig(png, dpi=dpi, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")          # vector — crisp at any zoom
    return png, pdf
