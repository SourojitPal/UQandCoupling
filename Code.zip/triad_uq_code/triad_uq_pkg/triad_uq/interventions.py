"""
Interventions (Rev.2 plan section 6). Each returns a target-adapted ensemble
{theta_k'} that coexists with the source-only ensemble {theta_k}; the two
regimes are the S/T axis of the joint grid. Active learning and fine-tuning
spend the SAME label budget for a fair H2 contrast.
"""
from __future__ import annotations
import numpy as np
from .models import BaggedEnsemble


def baseline_ensemble(Xs, ys, base="rf", K=25, seed=0) -> BaggedEnsemble:
    return BaggedEnsemble(base=base, K=K, seed=seed).fit(Xs, ys)


def finetune_selftrain(Xs, ys, Xt_adapt, yt_adapt, Xt_pool=None,
                       base="rf", K=25, seed=0, target_upweight=3.0,
                       self_train_conf=0.9, source_model=None) -> BaggedEnsemble:
    """
    Refit on source-train U target-adapt (target upweighted). Optional
    self-training: add high-confidence pseudo-labelled target-pool points.
    """
    X = np.vstack([Xs, Xt_adapt])
    y = np.r_[ys, yt_adapt]
    w = np.r_[np.ones(len(ys)), np.full(len(yt_adapt), target_upweight)]

    if Xt_pool is not None and source_model is not None and len(Xt_pool):
        p = source_model.mean_proba(Xt_pool)
        conf = p.max(axis=1)
        mask = conf >= self_train_conf
        if mask.any():
            pseudo = source_model.classes_[p[mask].argmax(axis=1)]
            X = np.vstack([X, Xt_pool[mask]])
            y = np.r_[y, pseudo]
            w = np.r_[w, np.full(mask.sum(), target_upweight * 0.5)]

    return BaggedEnsemble(base=base, K=K, seed=seed).fit(X, y, sample_weight=w)


def bald_scores(member_proba: np.ndarray) -> np.ndarray:
    """BALD acquisition = Epistemic = H[mean] - mean[H]. member_proba: [K,N,C]."""
    from .info import entropy
    mean = member_proba.mean(axis=0)              # [N,C]
    total = entropy(mean, axis=1)                 # [N]
    ale = entropy(member_proba, axis=2).mean(0)   # [N]
    return total - ale


def active_learning(Xs, ys, Xt_pool, yt_pool, budget, base="rf", K=25,
                    seed=0, target_upweight=3.0) -> BaggedEnsemble:
    """
    Acquire `budget` labels from target-pool by highest BALD score, then refit
    on source U acquired (target upweighted).
    """
    src = BaggedEnsemble(base=base, K=K, seed=seed).fit(Xs, ys)
    scores = bald_scores(src.member_proba(Xt_pool))
    take = np.argsort(scores)[::-1][:min(budget, len(Xt_pool))]
    X = np.vstack([Xs, Xt_pool[take]])
    y = np.r_[ys, yt_pool[take]]
    w = np.r_[np.ones(len(ys)), np.full(len(take), target_upweight)]
    return BaggedEnsemble(base=base, K=K, seed=seed).fit(X, y, sample_weight=w)
