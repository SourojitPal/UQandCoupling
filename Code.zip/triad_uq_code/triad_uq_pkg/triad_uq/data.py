"""
Data layer: UCI Heart Disease, four real hospital sites on one shared schema
(Rev.2 plan section 4). Shift is supplied by the SITE BOUNDARY -- no synthetic
shift anywhere in the REPORTED experiment.

`load_sites` obtains the four sites (cleveland / hungarian / switzerland / va)
from the first source that works, in this order:

  1. Local per-site CSVs in `data_dir`  (authoritative; classic processed.*
     files: comma-separated, no header, '?' = missing, last column = target).
  2. UCI archive              -- the official per-site processed.* files.
  3. Hugging Face             -- a combined heart_disease_uci.csv mirror that
                                 carries a site column ('dataset').
  4. Kaggle (via kagglehub)   -- redwankarimsony/heart-disease-data (combined,
                                 with a site column); needs Kaggle credentials.
  5. Synthetic fallback       -- clearly labelled, LOUDLY marked NOT FOR
                                 REPORTING, so the notebook still runs end-to-end
                                 with no network.

Anything downloaded is cached into `data_dir` as per-site CSVs, so subsequent
runs are fully offline. `data.LAST_PROVENANCE` records which source was used.

Target is binarized: 0 = absence, >=1 = presence.
Leakage rule: imputers/scalers are fit on SOURCE-TRAIN only and applied
elsewhere (see split_pair).
"""
from __future__ import annotations
import io
import os
import glob
import zipfile
import urllib.request
from dataclasses import dataclass, field
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

SITES = ["cleveland", "hungarian", "switzerland", "va"]
FEATURES = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
            "thalach", "exang", "oldpeak", "slope", "ca", "thal"]

# Records which source load_sites actually used (local/uci/huggingface/kaggle/synthetic).
LAST_PROVENANCE: str | None = None

# --- download sources (edit/extend freely; all failures are non-fatal) --------
_UCI_ZIP_URL = "https://archive.ics.uci.edu/static/public/45/heart+disease.zip"
_UCI_FILE_URL = ("https://archive.ics.uci.edu/ml/machine-learning-databases/"
                 "heart-disease/processed.{stem}.data")
_UCI_STEMS = {"cleveland": "cleveland", "hungarian": "hungarian",
              "switzerland": "switzerland", "va": "va"}

# Combined mirrors (must contain a site column 'dataset' + 13 features + target).
_HF_URLS = [
    "https://huggingface.co/datasets/redwankarimsony/heart-disease-data/"
    "resolve/main/heart_disease_uci.csv",
    "https://huggingface.co/datasets/imodels/heart-disease/"
    "resolve/main/heart_disease_uci.csv",
]
_KAGGLE_DATASET = "redwankarimsony/heart-disease-data"

# Map the many spellings of the site label (combined files) to our keys.
_SITE_ALIASES = {
    "cleveland": "cleveland",
    "hungary": "hungarian", "hungarian": "hungarian", "budapest": "hungarian",
    "switzerland": "switzerland", "swiss": "switzerland",
    "va long beach": "va", "va": "va", "long beach": "va", "va_long_beach": "va",
}


@dataclass
class Site:
    name: str
    X: pd.DataFrame
    y: np.ndarray
    n: int = field(init=False)

    def __post_init__(self):
        self.n = len(self.y)


def _binarize(y):
    return (np.asarray(y, dtype=float) >= 1).astype(int)


# --------------------------------------------------------------- parsing helpers
def _parse_processed(source) -> tuple[pd.DataFrame, np.ndarray]:
    """Parse a classic processed.*.data file (14 numeric cols, no header, '?')."""
    raw = pd.read_csv(source, header=None, na_values="?")
    if raw.shape[1] < 14:
        raise ValueError(f"expected >=14 columns, got {raw.shape[1]}")
    raw = raw.iloc[:, :14]
    raw.columns = FEATURES + ["target"]
    X = raw[FEATURES].apply(pd.to_numeric, errors="coerce")
    y = _binarize(pd.to_numeric(raw["target"], errors="coerce").values)
    return X, y


def _encode_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Return a numeric [n, len(FEATURES)] frame from a combined file whose columns
    may be human-readable strings ("Male"/"typical angina"/TRUE...). Encoding is
    done on the WHOLE combined frame so category codes are consistent across
    sites. Missing values are preserved as NaN.
    """
    out = pd.DataFrame(index=df.index)
    for f in FEATURES:
        col = df[f] if f in df.columns else pd.Series(np.nan, index=df.index)
        num = pd.to_numeric(col, errors="coerce")
        if num.notna().any():
            out[f] = num
            continue
        s = col.astype("string").str.strip().str.lower()
        s = s.replace({"true": "1", "false": "0", "yes": "1", "no": "0",
                       "male": "1", "female": "0"})
        num2 = pd.to_numeric(s, errors="coerce")
        if num2.notna().any():
            out[f] = num2
            continue
        cats = pd.Categorical(s)
        codes = cats.codes.astype(float)
        codes[cats.codes < 0] = np.nan            # keep <NA> as NaN, not -1
        out[f] = codes
    # Force plain float64 so DataFrame.values is a clean float ndarray for
    # sklearn (nullable Int64/bool columns would otherwise become object).
    return out.astype("float64")


def _sites_from_combined(df: pd.DataFrame) -> dict:
    """Split a combined heart_disease_uci-style frame into {site: Site}."""
    df = df.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]
    df = df.rename(columns={"thalch": "thalach", "num": "target"})

    site_col = next((c for c in ("dataset", "site", "origin") if c in df.columns), None)
    if site_col is None:
        raise ValueError("combined frame has no site column (dataset/site/origin)")
    tgt_col = "target" if "target" in df.columns else df.columns[-1]

    Xall = _encode_features(df)
    yall = _binarize(pd.to_numeric(df[tgt_col], errors="coerce").values)
    norm = (df[site_col].astype("string").str.strip().str.lower()
            .map(lambda v: _SITE_ALIASES.get(v, None)))

    sites = {}
    for key in SITES:
        mask = (norm == key).values
        if mask.sum() == 0:
            continue
        sites[key] = Site(key, Xall[mask].reset_index(drop=True), yall[mask])
    return sites


def _http_get(url: str, timeout: int = 30) -> bytes | None:
    """GET url -> bytes, or None on any failure (offline, 404, timeout...)."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "triad-uq/0.2"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except Exception:
        return None


# ------------------------------------------------------------------- source: local
def _load_local(data_dir: str) -> dict:
    sites = {}
    for s in SITES:
        fp = os.path.join(data_dir, f"{s}.csv")
        if not os.path.exists(fp):
            continue
        try:
            X, y = _parse_processed(fp)
            sites[s] = Site(s, X, y)
        except Exception as e:
            print(f"[data] could not parse {fp}: {e}")
    return sites


# --------------------------------------------------------------------- source: UCI
def _download_uci() -> dict:
    sites = {}
    blob = _http_get(_UCI_ZIP_URL)
    if blob:
        try:
            zf = zipfile.ZipFile(io.BytesIO(blob))
            for key, stem in _UCI_STEMS.items():
                name = next((n for n in zf.namelist()
                             if n.endswith(f"processed.{stem}.data")), None)
                if name:
                    X, y = _parse_processed(io.BytesIO(zf.read(name)))
                    sites[key] = Site(key, X, y)
        except Exception:
            pass
    if len(sites) < 2:                                 # fall back to per-file URLs
        for key, stem in _UCI_STEMS.items():
            if key in sites:
                continue
            b = _http_get(_UCI_FILE_URL.format(stem=stem))
            if b:
                try:
                    X, y = _parse_processed(io.BytesIO(b))
                    sites[key] = Site(key, X, y)
                except Exception:
                    pass
    return sites


# ------------------------------------------------------------- source: HuggingFace
def _download_huggingface() -> dict:
    for url in _HF_URLS:
        b = _http_get(url)
        if not b:
            continue
        try:
            df = pd.read_csv(io.BytesIO(b))
            sites = _sites_from_combined(df)
            if len(sites) >= 2:
                return sites
        except Exception:
            continue
    return {}


# ------------------------------------------------------------------ source: Kaggle
def _download_kaggle() -> dict:
    try:
        import kagglehub
    except Exception:
        print("[data] kaggle: kagglehub not installed (pip install kagglehub) -- skipping.")
        return {}
    try:
        path = kagglehub.dataset_download(_KAGGLE_DATASET)
    except Exception as e:
        print(f"[data] kaggle: download failed ({e}); needs Kaggle credentials -- skipping.")
        return {}
    for fp in glob.glob(os.path.join(path, "**", "*.csv"), recursive=True):
        try:
            df = pd.read_csv(fp)
            sites = _sites_from_combined(df)
            if len(sites) >= 2:
                return sites
        except Exception:
            continue
    return {}


# --------------------------------------------------------------- source: synthetic
def _synthetic_sites(seed: int = 0) -> dict:
    print("\n" + "!" * 74)
    print("!!  WARNING: no real UCI data found and all downloads failed.")
    print("!!  Falling back to SYNTHETIC multi-site data so the notebook runs")
    print("!!  end-to-end. These numbers are PLUMBING ONLY -- NOT FOR REPORTING.")
    print("!!  Put the real CSVs in data/ (or restore internet) for the real run.")
    print("!" * 74 + "\n")
    specs = {"cleveland": (303, 0.0), "hungarian": (294, 0.7),
             "switzerland": (123, 1.1), "va": (200, 0.9)}
    sites = {}
    for offset, (name, (n, shift)) in enumerate(specs.items()):
        r = np.random.default_rng(seed + 101 * (offset + 1))
        Xc = r.normal(shift, 1.0, size=(n, len(FEATURES)))
        df = pd.DataFrame(Xc, columns=FEATURES)
        logit = 0.8 * Xc[:, 0] - 0.6 * Xc[:, 3] + 0.5 * Xc[:, 7] + r.normal(0, 1, n)
        y = (logit > np.median(logit)).astype(int)
        for c in ("ca", "thal", "slope"):             # realistic missingness
            df.loc[r.random(n) < 0.15, c] = np.nan
        sites[name] = Site(name, df, y)
    return sites


def _cache_sites(sites: dict, data_dir: str) -> None:
    """Write each site to <name>.csv (numeric, no header, '?' for NaN)."""
    try:
        os.makedirs(data_dir, exist_ok=True)
        for name, s in sites.items():
            out = s.X.copy()
            out["target"] = s.y
            out.to_csv(os.path.join(data_dir, f"{name}.csv"),
                       header=False, index=False, na_rep="?")
    except Exception as e:
        print(f"[data] (could not cache to {data_dir}: {e})")


def _report(sites: dict, source: str) -> None:
    global LAST_PROVENANCE
    LAST_PROVENANCE = source
    print(f"[data] source = {source}")
    for name in SITES:
        if name in sites:
            s = sites[name]
            miss = float(s.X.isna().mean().mean())
            print(f"[data] {name:12s} n={s.n:4d}  pos_rate={float(np.mean(s.y)):.2f}  "
                  f"mean_missing={miss:.2f}")


def load_sites(data_dir: str | None = None, allow_download: bool = True,
               sources: tuple = ("uci", "huggingface", "kaggle"),
               allow_synthetic_fallback: bool = True, cache: bool = True,
               verbose: bool = True) -> dict:
    """
    Return {site_name: Site}, trying local CSVs -> downloads -> synthetic.

    data_dir                 : folder for local CSVs and the download cache.
    allow_download           : try the network sources in `sources`.
    sources                  : order of remote sources to attempt.
    allow_synthetic_fallback : if everything fails, return labelled synthetic
                               data (LOUDLY marked NOT FOR REPORTING) instead of
                               raising, so the notebook still completes.
    cache                    : write fetched data back to data_dir as CSVs.
    """
    # 1) local (authoritative)
    if data_dir:
        local = _load_local(data_dir)
        if len(local) >= 2:
            if verbose:
                _report(local, "local")
            return local

    # 2) downloads
    fetchers = {"uci": _download_uci, "huggingface": _download_huggingface,
                "kaggle": _download_kaggle}
    if allow_download:
        for src in sources:
            fn = fetchers.get(src)
            if fn is None:
                continue
            if verbose:
                print(f"[data] trying source: {src} ...")
            got = fn()
            if len(got) >= 2:
                if cache and data_dir:
                    _cache_sites(got, data_dir)
                if verbose:
                    _report(got, src)
                return got

    # 3) synthetic fallback
    if allow_synthetic_fallback:
        syn = _synthetic_sites()
        if verbose:
            _report(syn, "SYNTHETIC (NOT FOR REPORTING)")
        return syn

    raise RuntimeError(
        "No site data found and downloads failed. Provide a data_dir with the "
        "per-site CSVs cleveland.csv / hungarian.csv / switzerland.csv / va.csv, "
        "restore internet for the UCI/HuggingFace/Kaggle sources, or set "
        "allow_synthetic_fallback=True."
    )


def _viable_features(src: Site, tgt: Site, max_missing: float = 0.5):
    """
    Columns usable for a pair: those present in BOTH sites whose missingness
    stays <= max_missing in each. Iterating the Site's own columns (rather than
    the fixed tabular FEATURES list) keeps tabular behaviour identical while
    letting the pipeline run on arbitrary feature sets -- image embeddings or a
    fused tabular+image vector (see encoders.py / multimodal.py).
    """
    shared = [c for c in src.X.columns if c in set(tgt.X.columns)]
    return [c for c in shared
            if src.X[c].isna().mean() <= max_missing
            and tgt.X[c].isna().mean() <= max_missing]


@dataclass
class PairSplit:
    features: list
    Xs_train: np.ndarray; ys_train: np.ndarray
    Xs_holdout: np.ndarray; ys_holdout: np.ndarray   # in-domain held-out source
    Xt_adapt: np.ndarray; yt_adapt: np.ndarray
    Xt_pool: np.ndarray;  yt_pool: np.ndarray
    Xt_test: np.ndarray;  yt_test: np.ndarray
    scaler: StandardScaler
    imputer: SimpleImputer


def split_pair(src: Site, tgt: Site, seed: int = 0,
               p_test: float = 0.4, p_pool: float = 0.4, p_adapt: float = 0.2,
               p_source_holdout: float = 0.2, max_missing: float = 0.5) -> PairSplit:
    """
    Carve a source->target pair into the four roles (Rev.2 plan section 4.2),
    fitting imputer+scaler on SOURCE-TRAIN only.
    """
    feats = _viable_features(src, tgt, max_missing)

    Xs = src.X[feats].values; ys = src.y
    Xs_tr, Xs_ho, ys_tr, ys_ho = train_test_split(
        Xs, ys, test_size=p_source_holdout, random_state=seed, stratify=ys)

    imputer = SimpleImputer(strategy="median").fit(Xs_tr)
    scaler = StandardScaler().fit(imputer.transform(Xs_tr))

    def prep(A):
        return scaler.transform(imputer.transform(A))

    Xt = tgt.X[feats].values; yt = tgt.y
    # target: test vs (adapt+pool)
    Xt_test, Xt_rest, yt_test, yt_rest = train_test_split(
        Xt, yt, test_size=(1 - p_test), random_state=seed, stratify=yt)
    # rest -> pool vs adapt
    rel_adapt = p_adapt / (p_adapt + p_pool)
    Xt_pool, Xt_adapt, yt_pool, yt_adapt = train_test_split(
        Xt_rest, yt_rest, test_size=rel_adapt, random_state=seed, stratify=yt_rest)

    return PairSplit(
        features=feats,
        Xs_train=prep(Xs_tr), ys_train=ys_tr,
        Xs_holdout=prep(Xs_ho), ys_holdout=ys_ho,
        Xt_adapt=prep(Xt_adapt), yt_adapt=yt_adapt,
        Xt_pool=prep(Xt_pool), yt_pool=yt_pool,
        Xt_test=prep(Xt_test), yt_test=yt_test,
        scaler=scaler, imputer=imputer,
    )
