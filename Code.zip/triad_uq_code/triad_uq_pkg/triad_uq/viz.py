"""
Publication-style figures for TRIAD-UQ (and reusable beyond it).

Two figure makers, styled after common backdoor-defense papers:

  plot_strip_entropy(...)  -- STRIP-style overlapping entropy histograms for a
                              "clean" vs a "trojaned"/shifted group, with a
                              detection threshold, a shaded rejection band, and
                              an FRR / FAR / AUC stats box (one panel per model).
  plot_tsne3d(...)         -- 3-D t-SNE of a feature matrix rendered from two
                              azimuths, coloured by an arbitrary group label.

Both are fully general: pass your own arrays (e.g. real STRIP entropies or CNN
feature vectors) to reproduce the exact figure style for any experiment. The
TRIAD notebook also calls them on the pipeline's own quantities so every run
drops these figures into its output folder.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt

_CLEAN_C = "#3b6fb6"      # blue
_TROJ_C = "#b63b3b"       # red
_PALETTE = ["#2ca02c", "#1f77b4", "#d62728", "#9467bd",
            "#ff7f0e", "#8c564b", "#17becf", "#bcbd22"]


# ------------------------------------------------------------------ STRIP style
def strip_threshold(clean: np.ndarray, target_frr: float = 0.01) -> float:
    """
    STRIP convention: an input is flagged as trojaned when its prediction
    entropy is BELOW a threshold. Choose that threshold as the `target_frr`
    quantile of the clean entropies, so the clean false-reject rate ~ target_frr.
    """
    clean = np.asarray(clean, float)
    return float(np.quantile(clean, target_frr))


def _auc_low_is_trojan(clean: np.ndarray, trojan: np.ndarray) -> float:
    """AUC for 'lower entropy => trojaned' (rank-based; no sklearn dependency)."""
    clean = np.asarray(clean, float); trojan = np.asarray(trojan, float)
    nc, nt = len(clean), len(trojan)
    if nc == 0 or nt == 0:
        return float("nan")
    allv = np.concatenate([clean, trojan])
    ranks = allv.argsort().argsort().astype(float) + 1.0     # average ranks ~ok
    r_troj = ranks[nc:].sum()
    # Mann-Whitney: prob(clean entropy > trojan entropy)
    u = r_troj - nt * (nt + 1) / 2.0
    return float(u / (nc * nt))


def plot_strip_entropy(panels, threshold: float | None = None,
                       target_frr: float = 0.01, bins: int = 40, ncols: int = 2,
                       figsize=None, suptitle: str | None = None,
                       clean_label: str = "Clean", trojan_label: str = "Trojaned",
                       title_size=None, label_size=None, tick_size=None,
                       suptitle_size=None, legend_size: int = 14, stats_size: int = 14,
                       one_row: bool = False, savepath: str | None = None):
    """
    panels : list of dicts, each {"title", "clean", "trojan", optional "threshold"}.
             `clean`/`trojan` are 1-D entropy arrays.
    clean_label / trojan_label : legend names for the two groups. For a domain-
             shift study pass ("In-domain", "Shifted"); the STRIP-paper default
             is ("Clean", "Trojaned").
    one_row  : lay all panels in a single row (ncols = number of panels).
    *_size   : font sizes; None -> the house style (Times New Roman rcParams).
    Returns the Matplotlib Figure. Saves a PNG if `savepath` is given.
    """
    from . import plotstyle; plotstyle.apply_style()
    n = len(panels)
    ncols = n if (one_row and n) else (min(ncols, n) if n else 1)
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols,
                             figsize=figsize or (6.2 * ncols, 4.1 * nrows),
                             squeeze=False)
    for k, p in enumerate(panels):
        ax = axes[k // ncols][k % ncols]
        clean = np.asarray(p["clean"], float)
        troj = np.asarray(p["trojan"], float)
        thr = p.get("threshold", threshold)
        if thr is None:
            thr = strip_threshold(clean, target_frr)

        lo = float(min(clean.min(), troj.min()))
        hi = float(max(clean.max(), troj.max()))
        edges = np.linspace(lo, hi, bins + 1)
        ax.hist(clean, bins=edges, alpha=0.7, color=_CLEAN_C,
                label=f"{clean_label} (n={len(clean)})")
        ax.hist(troj, bins=edges, alpha=0.7, color=_TROJ_C,
                label=f"{trojan_label} (n={len(troj)})")
        ax.axvspan(lo, thr, color="red", alpha=0.10)          # rejection region
        ax.axvline(thr, ls="--", lw=1.3, color="k",
                   label=f"threshold = {thr:.3f}")

        frr = float(np.mean(clean < thr)) * 100.0             # clean wrongly flagged
        far = float(np.mean(troj >= thr)) * 100.0             # trojan missed
        auc = _auc_low_is_trojan(clean, troj)
        ax.text(0.97, 0.95, f"FRR = {frr:.1f}%\nFAR = {far:.1f}%\nAUC = {auc:.3f}",
                transform=ax.transAxes, ha="right", va="top", fontsize=stats_size,
                bbox=dict(boxstyle="round", fc="#e8f5e9", ec="#66bb6a"))
        ax.set_title(p.get("title", f"panel {k}"), fontsize=title_size)
        ax.set_xlabel(r"entropy  $H=-\sum p\log p$", fontsize=label_size)
        ax.set_ylabel("count", fontsize=label_size)
        if tick_size:
            ax.tick_params(labelsize=tick_size)
        ax.legend(fontsize=legend_size, loc="upper left")

    for k in range(n, nrows * ncols):                          # blank spares
        axes[k // ncols][k % ncols].axis("off")
    if suptitle:
        fig.suptitle(suptitle, fontsize=suptitle_size)
    fig.tight_layout()
    if savepath:
        fig.savefig(savepath, dpi=150, bbox_inches="tight")
    return fig


# ------------------------------------------------------------------- t-SNE style
def plot_tsne3d(X, groups, views=((30, "View A - azimuth 30"),
                                  (140, "View B - azimuth 140")),
                elev: int = 18, palette=None, perplexity: float = 30.0,
                seed: int = 0, suptitle: str | None = None,
                title_size=None, label_size=None, legend_size: int = 14,
                suptitle_size=None, savepath: str | None = None):
    """
    X        : [N, D] feature matrix.
    groups   : length-N array of group labels (strings) -> colour + legend.
    views    : iterable of (azimuth, title) rendered as side-by-side 3-D panels.
    Returns (fig, embedding[N,3]). Saves a PNG if `savepath` is given.
    """
    from . import plotstyle; plotstyle.apply_style()
    from sklearn.manifold import TSNE
    X = np.asarray(X, float)
    groups = np.asarray(groups)
    n = len(X)
    perp = max(2, min(perplexity, (n - 1) // 3))
    perp = float(min(perp, n - 1))                 # sklearn requires perplexity < n
    emb = TSNE(n_components=3, random_state=seed, perplexity=perp,
               init="pca").fit_transform(X)

    uniq = list(dict.fromkeys(groups.tolist()))
    if palette is None:
        palette = {g: _PALETTE[i % len(_PALETTE)] for i, g in enumerate(uniq)}

    views = list(views)
    fig = plt.figure(figsize=(6.4 * len(views), 5.3))
    last_ax = None
    for j, (azim, vtitle) in enumerate(views):
        ax = fig.add_subplot(1, len(views), j + 1, projection="3d")
        for g in uniq:
            m = groups == g
            ax.scatter(emb[m, 0], emb[m, 1], emb[m, 2], s=10, alpha=0.75,
                       color=palette[g], label=str(g), depthshade=True)
        ax.view_init(elev=elev, azim=azim)
        ax.set_title(vtitle, fontsize=title_size)
        ax.set_xlabel("t-SNE 1", fontsize=label_size); ax.set_ylabel("t-SNE 2", fontsize=label_size); ax.set_zlabel("t-SNE 3", fontsize=label_size)
        last_ax = ax
    handles, labels = last_ax.get_legend_handles_labels()
    fig.legend(handles, labels, title="Group", loc="center right", fontsize=legend_size)
    if suptitle:
        fig.suptitle(suptitle, fontsize=suptitle_size)
    fig.tight_layout(rect=(0, 0, 0.86, 1))
    if savepath:
        fig.savefig(savepath, dpi=150, bbox_inches="tight")
    return fig, emb


# --------------------------------------------------- predictor vs Δ(each term)
def plot_terms_vs_predictor(predictor, deltas, predictor_name="baseline-regime Coupling(x*)",
                            seed: int = 0, ncols: int = 2, figsize=None, show_fit: bool = True,
                            title_size=None, label_size=None, tick_size=None, suptitle_size=None,
                            legend_size: int = 14, suptitle: str | None = None, savepath: str | None = None):
    """
    Generalise the H3 scatter to several response terms at once.

    predictor : 1-D array, the per-point predictor (e.g. baseline-regime Coupling).
    deltas    : ordered dict {term_name: Δterm array} (same length as predictor),
                e.g. finetune-minus-baseline for epistemic / aleatoric /
                distributional / coupling.
    Each panel scatters predictor vs Δterm, draws the OLS fit line, and annotates
    the OUT-OF-SAMPLE R^2 and permutation p (the same H3 statistic, computed on a
    fit/eval half-split), so every term is judged like the headline H3 test.
    Returns the Matplotlib Figure.
    """
    from . import plotstyle; plotstyle.apply_style()
    from .hypotheses import h3_coupling_predicts_epistemic as _h3
    x = np.asarray(predictor, float)
    items = list(deltas.items())
    n = len(items)
    ncols = min(ncols, n) if n else 1
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols,
                             figsize=figsize or (5.4 * ncols, 4.0 * nrows),
                             squeeze=False)
    for k, (term, dy) in enumerate(items):
        ax = axes[k // ncols][k % ncols]
        y = np.asarray(dy, float)
        ax.scatter(x, y, s=14, alpha=0.6, color=_CLEAN_C)
        if show_fit and len(x) >= 2 and np.ptp(x) > 0:
            a, b = np.polyfit(x, y, 1)
            xs = np.array([x.min(), x.max()])
            ax.plot(xs, a * xs + b, color=_TROJ_C, lw=1.6)
        try:
            st = _h3(x, y, seed=seed)
            tag = f"R$^2_{{oos}}$={st['r2_out_of_sample']:.2f}, p={st['perm_p']:.3f}"
        except Exception:
            tag = ""
        ax.set_title(f"Δ{term}   {tag}", fontsize=title_size)   # None -> rcParams
        ax.set_xlabel(predictor_name, fontsize=label_size)
        ax.set_ylabel(f"Δ{term}(x*)", fontsize=label_size)
        if tick_size:
            ax.tick_params(labelsize=tick_size)
        ax.axhline(0, color="0.7", lw=0.8, ls=":")
    for k in range(n, nrows * ncols):
        axes[k // ncols][k % ncols].axis("off")
    if suptitle:
        fig.suptitle(suptitle, fontsize=suptitle_size)
    fig.tight_layout()
    if savepath:
        fig.savefig(savepath, dpi=150, bbox_inches="tight")
    return fig
