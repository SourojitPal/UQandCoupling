"""
Null and positive controls (Rev.2 plan section 3.3). These are the cheapest,
highest-credibility evidence in the paper. H1-H5 are only interpretable once
these pass, so they run first and are reported first.

  permute_z_null      : shuffle the domain regime -> Distributional & Coupling
                        must COLLAPSE toward 0. If not, the estimator reads
                        artifact (fatal).
  no_shift_control    : source -> held-out source (Cleveland -> Cleveland).
                        Distributional ~ 0, Coupling ~ 0 confirms it is genuine
                        shift, not pipeline noise, that drives the terms.
"""
from __future__ import annotations
import numpy as np
from .joint_grid import decompose_set


def permute_z_null(P_S_all: np.ndarray, P_T_all: np.ndarray, pi_all: np.ndarray,
                   n_perm: int = 20, seed: int = 0) -> dict:
    """
    Break the association between the Z-axis and y by shuffling, across points,
    which regime is 'source' vs 'target-adapted'. Returns mean |Distributional|
    and |Coupling| under the null; both should be near 0.
    """
    rng = np.random.default_rng(seed)
    N = P_S_all.shape[0]
    dist_null, coup_null = [], []
    for _ in range(n_perm):
        swap = rng.random(N) < 0.5
        Ps = np.where(swap[:, None, None], P_T_all, P_S_all)
        Pt = np.where(swap[:, None, None], P_S_all, P_T_all)
        # also shuffle pi across points to destroy the x*-specific domain signal
        pi_perm = pi_all[rng.permutation(N)]
        d = decompose_set(Ps, Pt, pi_perm)
        dist_null.append(np.mean(np.abs(d["distributional"])))
        coup_null.append(np.mean(np.abs(d["coupling"])))
    return {
        "distributional_null_mean": float(np.mean(dist_null)),
        "distributional_null_std": float(np.std(dist_null)),
        "coupling_null_mean": float(np.mean(coup_null)),
        "coupling_null_std": float(np.std(coup_null)),
    }


def no_shift_summary(terms_no_shift: dict) -> dict:
    """
    Summarize a source->held-out-source run. Expect distributional and coupling
    means ~0. `terms_no_shift` is the output of decompose_set on the no-shift pair.
    """
    return {
        "distributional_mean": float(np.mean(terms_no_shift["distributional"])),
        "coupling_mean": float(np.mean(terms_no_shift["coupling"])),
        "epistemic_mean": float(np.mean(terms_no_shift["epistemic"])),
    }
