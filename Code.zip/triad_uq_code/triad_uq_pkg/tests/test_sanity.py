"""
Estimator-validation harness (Rev.2 plan section 9 / build order Day 1-2).

The single most important gate: if the XOR joint does not produce NEGATIVE
Coupling, the sign convention is wrong and no real-data result is meaningful.

Run:  python -m pytest tests/test_sanity.py -v
  or: python tests/test_sanity.py
"""
import os, sys
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from triad_uq.info import decompose_from_joint
from triad_uq.joint_grid import decompose_point
from triad_uq import synthetic as syn

LN2 = np.log(2.0)
ATOL = 1e-9


def _check_common(d):
    # closure to machine precision (correctness gate)
    assert abs(d["residual"]) < 1e-10, f"identity did not close: {d['residual']}"
    # every PID atom non-negative
    for a in ("redundancy", "unique_theta", "unique_z", "synergy"):
        assert d[a] > -1e-9, f"{a} negative: {d[a]}"
    # five-way atoms sum to Total
    five = d["aleatoric"] + d["unique_theta"] + d["unique_z"] + d["redundancy"] + d["synergy"]
    assert abs(five - d["total"]) < 1e-9, f"five-way sum {five} != total {d['total']}"
    # Coupling == Redundancy - Synergy
    assert abs(d["coupling"] - (d["redundancy"] - d["synergy"])) < 1e-9


def test_redundant():
    d = decompose_from_joint(syn.joint_redundant())
    _check_common(d)
    assert d["coupling"] > 0, "redundant case must give Coupling > 0"
    assert abs(d["coupling"] - LN2) < ATOL
    assert abs(d["synergy"]) < ATOL
    assert abs(d["redundancy"] - LN2) < ATOL


def test_xor():
    d = decompose_from_joint(syn.joint_xor())
    _check_common(d)
    assert d["coupling"] < 0, "XOR case must give Coupling < 0 (SIGN GATE)"
    assert abs(d["coupling"] + LN2) < ATOL
    assert abs(d["synergy"] - LN2) < ATOL
    assert abs(d["redundancy"]) < ATOL


def test_unique_theta():
    d = decompose_from_joint(syn.joint_unique_theta())
    _check_common(d)
    assert abs(d["coupling"]) < ATOL, "unique case: Coupling ~ 0"
    assert abs(d["unique_theta"] - LN2) < ATOL
    assert abs(d["unique_z"]) < ATOL


def test_independent():
    d = decompose_from_joint(syn.joint_independent())
    _check_common(d)
    for k in ("epistemic", "distributional", "coupling", "i_ykz",
              "unique_theta", "unique_z", "redundancy", "synergy"):
        assert abs(d[k]) < ATOL, f"{k} should be ~0 for independent case"


def test_grid_path_matches_and_closes():
    # A random two-regime ensemble grid: closure must still hold to ~1e-12.
    rng = np.random.default_rng(0)
    K, C = 25, 2
    P_S = rng.dirichlet(np.ones(C), size=K)
    P_T = rng.dirichlet(np.ones(C), size=K)
    for pi in (0.0, 0.3, 0.5, 0.8, 1.0):
        d = decompose_point(P_S, P_T, pi)
        assert abs(d["residual"]) < 1e-10, f"grid residual at pi={pi}: {d['residual']}"


if __name__ == "__main__":
    tests = [test_redundant, test_xor, test_unique_theta,
             test_independent, test_grid_path_matches_and_closes]
    for tfn in tests:
        tfn()
        print(f"PASS  {tfn.__name__}")
    print("\nAll estimator-validation checks passed.")
