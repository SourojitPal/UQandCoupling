"""
Real image DOMAINS for the multimodal / domain-shift experiment.

Objective (matches TRIAD-UQ): decompose predictive uncertainty across a
domain / distribution shift on IMAGES, exactly as the tabular pipeline does
across hospital sites. This module supplies two image domains (a "source" and
a "target") from REAL images, trying in order:

  1. torchvision  : MNIST (source) -> USPS (target) -- a genuine CROSS-DATASET
                    shift (two separately collected handwritten-digit corpora).
                    Needs `torch`/`torchvision` + a one-time download.
  2. OpenML       : mnist_784 real images, split into two REAL intensity domains
                    (thin- vs thick-stroke) stratified by class. Needs internet.
  3. scikit-learn : the bundled `load_digits` (1797 real 8x8 digit images),
                    same stratified thin/thick intensity split. OFFLINE, always
                    available -- the guaranteed real-image path.
  4. synthetic    : shapes, LOUDLY marked NOT FOR REPORTING (last resort only).

`LAST_IMAGE_PROVENANCE` records exactly which ran; `last_reportable()` is True
for every REAL source and False for the synthetic fallback. The label is the
binary parity of the digit (odd vs even) so both domains share one label space
(P(y) held equal by the stratified split -> the shift is covariate, not label).
"""
from __future__ import annotations
import numpy as np

LAST_IMAGE_PROVENANCE: str | None = None


def last_reportable() -> bool:
    """True if the last load used REAL images (not the synthetic fallback)."""
    return bool(LAST_IMAGE_PROVENANCE
                and not str(LAST_IMAGE_PROVENANCE).startswith("SYNTHETIC"))


# ------------------------------------------------------------------- helpers
def _to_rgb_uint8(imgs, size: int = 32) -> np.ndarray:
    """[N,H,W] (any scale) -> [N,size,size,3] uint8, GLOBAL-scaled so that
    cross-image intensity differences (which define the domains) are kept."""
    from PIL import Image
    a = np.asarray(imgs, dtype="float32")
    hi = float(a.max()) if a.size else 1.0
    a = a / (hi + 1e-9) * 255.0
    out = []
    for im in a:
        p = Image.fromarray(im.astype("uint8"), mode="L").resize((size, size)).convert("RGB")
        out.append(np.asarray(p, dtype="uint8"))
    return np.stack(out)


def _parity(y) -> np.ndarray:
    return (np.asarray(y).astype(int) % 2 == 1).astype(int)   # 1 = odd


def _intensity_domains(imgs_u8: np.ndarray, y_bin: np.ndarray,
                       names=("thin", "thick")) -> dict:
    """
    Split into two domains by per-image ink (sum of intensity), stratified
    WITHIN each label so both domains share the same P(y). The domains then
    differ in stroke thickness only -> a clean covariate shift on real images.
    """
    ink = imgs_u8.reshape(len(imgs_u8), -1).astype(float).sum(1)
    thin = np.zeros(len(y_bin), dtype=bool)
    for c in np.unique(y_bin):
        idx = np.where(y_bin == c)[0]
        thin[idx[ink[idx] <= np.median(ink[idx])]] = True
    return {names[0]: {"img": imgs_u8[thin], "y": y_bin[thin]},
            names[1]: {"img": imgs_u8[~thin], "y": y_bin[~thin]}}


def _cap(dom: dict, max_per_domain: int, seed: int) -> dict:
    """Cap each domain to max_per_domain, STRATIFIED by label so P(y) is kept."""
    rng = np.random.default_rng(seed)
    out = {}
    for k, d in dom.items():
        y = np.asarray(d["y"]); n = len(y)
        if n <= max_per_domain:
            out[k] = d
            continue
        sel = []
        for c in np.unique(y):
            idxc = np.where(y == c)[0]
            take = min(len(idxc), max(1, round(max_per_domain * len(idxc) / n)))
            sel.append(rng.choice(idxc, size=take, replace=False))
        sel = np.concatenate(sel)
        out[k] = {"img": d["img"][sel], "y": y[sel]}
    return out


# ------------------------------------------------------------------- sources
def _torchvision_domains(max_per_domain: int, size: int, seed: int) -> dict:
    import torch  # noqa: F401
    from torchvision import datasets
    import tempfile, os
    root = os.path.join(tempfile.gettempdir(), "triad_uq_tv")
    os.makedirs(root, exist_ok=True)

    def pack(ds, n):
        data = np.asarray(ds.data)
        if data.ndim == 4 and data.shape[-1] in (1, 3):          # USPS variants
            data = data[..., 0]
        targets = np.asarray(ds.targets)
        m = min(n, len(targets))
        idx = np.random.default_rng(seed).choice(len(targets), size=m, replace=False)
        return _to_rgb_uint8(data[idx], size), _parity(targets[idx])

    src = datasets.MNIST(root, train=True, download=True)
    tgt = datasets.USPS(root, train=True, download=True)
    xs, ys = pack(src, max_per_domain)
    xt, yt = pack(tgt, max_per_domain)
    return {"MNIST": {"img": xs, "y": ys}, "USPS": {"img": xt, "y": yt}}


def _openml_domains(max_per_domain: int, size: int, seed: int) -> dict:
    from sklearn.datasets import fetch_openml
    d = fetch_openml("mnist_784", version=1, as_frame=False)
    rng = np.random.default_rng(seed)
    n = min(2 * max_per_domain, len(d.target))
    sel = rng.choice(len(d.target), size=n, replace=False)
    imgs = d.data[sel].reshape(-1, 28, 28)
    y = _parity(d.target[sel])
    return _cap(_intensity_domains(_to_rgb_uint8(imgs, size), y), max_per_domain, seed)


def _digits_domains(max_per_domain: int, size: int, seed: int) -> dict:
    from sklearn.datasets import load_digits
    d = load_digits()
    return _cap(_intensity_domains(_to_rgb_uint8(d.images, size), _parity(d.target)),
                max_per_domain, seed)


def _synthetic_domains(max_per_domain: int, size: int, seed: int) -> dict:
    rng = np.random.default_rng(seed)
    dom = {}
    for name, shift in (("synthA", 0.0), ("synthB", 0.9)):
        n = max_per_domain
        y = (rng.random(n) < 0.5).astype(int)
        xx, yy = np.meshgrid(np.linspace(-1, 1, size), np.linspace(-1, 1, size))
        imgs = np.zeros((n, size, size, 3), dtype="uint8")
        for i, c in enumerate(y):
            mask = (xx**2 + yy**2) < 0.5 if c == 0 else (np.abs(xx) + np.abs(yy)) < 0.7
            base = mask * (0.6 + 0.4 * shift) + rng.normal(0, 0.05, (size, size))
            imgs[i] = np.clip(np.stack([base]*3, -1) * 255, 0, 255).astype("uint8")
        dom[name] = {"img": imgs, "y": y}
    return dom


# ------------------------------------------------------------------- loader
def load_image_domains(sources=("torchvision", "openml", "sklearn"),
                       allow_download: bool = True, allow_synthetic_fallback: bool = True,
                       max_per_domain: int = 600, size: int = 32,
                       seed: int = 0, verbose: bool = True) -> dict:
    """
    Return an ordered {domain_name: {"img": uint8[n,size,size,3], "y": [n]}}
    with exactly two REAL domains where possible. Records LAST_IMAGE_PROVENANCE.
    """
    global LAST_IMAGE_PROVENANCE
    attempts = []
    if allow_download:
        attempts += [
            ("torchvision", _torchvision_domains, "torchvision: MNIST(source) -> USPS(target)"),
            ("openml", _openml_domains, "openml: mnist_784 intensity-domains (thin/thick)"),
        ]
    # sklearn digits is offline + real -> always attemptable
    attempts.append(("sklearn", _digits_domains,
                     "sklearn: load_digits intensity-domains (thin/thick) [real images, offline]"))

    for key, fn, prov in attempts:
        if key not in sources and key != "sklearn":
            continue
        if key == "sklearn" and "sklearn" not in sources:
            continue
        try:
            if verbose:
                print(f"[image] trying source: {key} ...")
            dom = fn(max_per_domain, size, seed)
            if len(dom) >= 2 and all(len(d["y"]) > 10 for d in dom.values()):
                LAST_IMAGE_PROVENANCE = prov
                if verbose:
                    _report(dom, prov)
                return dom
        except Exception as e:
            if verbose:
                print(f"[image] source {key} unavailable ({str(e)[:70]})")

    if allow_synthetic_fallback:
        print("\n" + "!" * 74)
        print("!!  WARNING: no REAL image domains available (offline / missing deps).")
        print("!!  Falling back to SYNTHETIC image shapes -- PLUMBING ONLY, NOT FOR REPORTING.")
        print("!" * 74 + "\n")
        dom = _synthetic_domains(max_per_domain, size, seed)
        LAST_IMAGE_PROVENANCE = "SYNTHETIC shapes (NOT FOR REPORTING)"
        if verbose:
            _report(dom, LAST_IMAGE_PROVENANCE)
        return dom

    raise RuntimeError("No image domains available and synthetic fallback disabled.")


def _report(dom: dict, prov: str) -> None:
    print(f"[image] provenance = {prov}")
    for name, d in dom.items():
        y = np.asarray(d["y"])
        print(f"[image] {name:14s} n={len(y):5d}  odd_rate={float(y.mean()):.2f}  "
              f"img={d['img'].shape[1:]}")
