Place the UCI Heart Disease processed files here as:
  cleveland.csv  hungarian.csv  switzerland.csv  va.csv
(comma-separated, '?' = missing, last column = target)
