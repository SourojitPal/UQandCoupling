"""
Hypothesis tests H1-H5 (Rev.2 plan section 7). Controls (controls.py) must
pass before these are interpretable.

Inputs are the per-point term arrays produced by joint_grid.decompose_set at
each stage. H3 and H5 take baseline vs post-intervention arrays.
"""
from __future__ import annotations
import numpy as np
from scipy import stats


def _boot_ci(x, n=2000, seed=0, alpha=0.05):
    rng = np.random.default_rng(seed)
    x = np.asarray(x, float)
    bs = [np.mean(rng.choice(x, len(x), replace=True)) for _ in range(n)]
    lo, hi = np.percentile(bs, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(np.mean(x)), float(lo), float(hi)


def h1_regime(coupling: np.ndarray) -> dict:
    """H1: Coupling > 0 (redundancy-dominated). Also report sign variation --
    if it never flips, H3's SIGN claim is vacuous (Rev.2 plan section 7)."""
    mean, lo, hi = _boot_ci(coupling)
    try:
        w = stats.wilcoxon(coupling, alternative="greater").pvalue
    except ValueError:
        w = np.nan
    return {"coupling_mean": mean, "ci": (lo, hi),
            "wilcoxon_p_gt0": float(w),
            "frac_negative": float(np.mean(coupling < 0)),
            "sign_varies": bool(np.mean(coupling < 0) > 0.02)}


def h2_specificity(d_dist: np.ndarray, d_epi: np.ndarray, arm: str) -> dict:
    """
    H2: intervention specificity. For distributional arms expect
    |d_dist| > |d_epi|; for active learning expect the reverse.
    """
    diff = np.abs(d_dist) - np.abs(d_epi)
    try:
        p = stats.wilcoxon(diff).pvalue
    except ValueError:
        p = np.nan
    return {"arm": arm, "median_|dDist|-|dEpi|": float(np.median(diff)),
            "wilcoxon_p": float(p),
            "expected": "|dDist|>|dEpi|" if arm != "active" else "|dEpi|>|dDist|"}


def h3_coupling_predicts_epistemic(coupling_base: np.ndarray,
                                   d_epistemic: np.ndarray,
                                   seed: int = 0) -> dict:
    """
    H3 (headline, magnitude-first): does baseline Coupling predict the change in
    Epistemic after a distributional intervention, OUT OF SAMPLE?
    Fit on H3-fit half, evaluate on H3-eval half. Cross-intervention when
    d_epistemic comes from a different intervention than Coupling's Z-axis.
    """
    rng = np.random.default_rng(seed)
    N = len(coupling_base)
    idx = rng.permutation(N)
    half = N // 2
    fit, ev = idx[:half], idx[half:]

    xf, yf = coupling_base[fit], d_epistemic[fit]
    xe, ye = coupling_base[ev], d_epistemic[ev]
    a, b = np.polyfit(xf, yf, 1)                    # slope, intercept on fit half
    pred = a * xe + b
    ss_res = np.sum((ye - pred) ** 2)
    ss_tot = np.sum((ye - ye.mean()) ** 2) + 1e-12
    r2_oos = 1.0 - ss_res / ss_tot
    sign_agree = float(np.mean(np.sign(pred - b) == np.sign(ye)))

    # permutation p on out-of-sample R^2
    perm_r2 = []
    for _ in range(500):
        yp = rng.permutation(ye)
        perm_r2.append(1.0 - np.sum((yp - pred) ** 2) / ss_tot)
    p_perm = (np.sum(np.array(perm_r2) >= r2_oos) + 1) / 501

    return {"slope": float(a), "r2_out_of_sample": float(r2_oos),
            "sign_agreement": sign_agree, "perm_p": float(p_perm)}


def h4_diagnostic(delta_atoms: dict, arm: str) -> dict:
    """
    H4: an intervention's dTotal is dominated by the atom the mapping predicts
    (fine-tune -> dSynergy+dUnique_Z; active -> dUnique_theta; coral -> dUnique_Z+dRedundancy).
    delta_atoms: dict of arrays for aleatoric/unique_theta/unique_z/redundancy/synergy deltas.
    """
    means = {k: float(np.mean(v)) for k, v in delta_atoms.items()}
    dominant = max(means, key=lambda k: abs(means[k]))
    predicted = {"finetune": {"synergy", "unique_z"},
                 "active": {"unique_theta"},
                 "coral": {"unique_z", "redundancy"}}.get(arm, set())
    return {"arm": arm, "dominant_atom": dominant,
            "predicted": sorted(predicted),
            "match": dominant in predicted, "means": means}


def h5_recovery(direct: np.ndarray, recovered: np.ndarray) -> dict:
    """
    H5: recover a term (Distributional) via the identity from route-B terms and
    match its independent direct measurement.

    The independent instrument (domain_mi_nats) is a SINGLE scalar for the whole
    test set, while `recovered` is per-point. A concordance/CCC between a
    constant and a vector is undefined, so this detects the scalar case and
    instead reports whether the independent value falls inside the bootstrap CI
    of the recovered mean (mode="scalar"). When both inputs genuinely vary
    per-point it reports CCC + Bland-Altman (mode="concordance").
    """
    d = np.asarray(direct, float).ravel()
    r = np.asarray(recovered, float).ravel()

    if np.unique(np.round(d, 12)).size == 1:            # scalar independent value
        d0 = float(d.flat[0])
        r_mean, lo, hi = _boot_ci(r)                    # CI of the recovered mean
        abs_err = abs(r_mean - d0)
        return {"mode": "scalar",
                "direct": d0, "recovered_mean": float(r_mean),
                "recovered_ci": (lo, hi),
                "abs_error": float(abs_err),
                "rel_error": float(abs_err / (abs(d0) + 1e-12)),
                "direct_in_recovered_ci": bool(lo <= d0 <= hi)}

    # per-point concordance: CCC + Bland-Altman
    md, mr = d.mean(), r.mean()
    vd, vr = d.var(), r.var()
    cov = np.mean((d - md) * (r - mr))
    ccc = 2 * cov / (vd + vr + (md - mr) ** 2 + 1e-12)
    diff = r - d
    bias, sd = float(diff.mean()), float(diff.std())
    _, lo, hi = _boot_ci(diff)
    return {"mode": "concordance", "ccc": float(ccc), "bias": bias,
            "loa_95": (bias - 1.96 * sd, bias + 1.96 * sd),
            "bias_ci": (lo, hi), "bias_ci_contains_0": bool(lo <= 0 <= hi)}
