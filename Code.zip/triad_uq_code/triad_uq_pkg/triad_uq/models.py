"""
Models (Rev.2 plan section 2.1 / 4). A bagged ensemble gives theta-variation
for epistemic estimation without a Bayesian neural network; member_proba
exposes per-member predictions -- the raw material for the joint grid.
"""
from __future__ import annotations
import numpy as np
from sklearn.ensemble import RandomForestClassifier, BaggingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier


class BaggedEnsemble:
    """
    Wraps RF (per-tree) or a Bagging ensemble of LR/DT. Always exposes
    member_proba(X) -> [K, N, C].
    """

    def __init__(self, base: str = "rf", K: int = 25, seed: int = 0, **kw):
        self.base = base; self.K = K; self.seed = seed
        if base == "rf":
            # Fully grown trees give one-hot predict_proba, which makes
            # H(y|k,z) -- and therefore Aleatoric -- structurally 0
            # (config.yaml documents this). Apply the config's soft-probability
            # defaults unless the caller explicitly overrides them.
            kw.setdefault("min_samples_leaf", 5)
            kw.setdefault("max_features", "sqrt")
            self.model = RandomForestClassifier(
                n_estimators=K, random_state=seed, **kw)
        elif base == "logreg":
            self.model = BaggingClassifier(
                LogisticRegression(max_iter=1000), n_estimators=K,
                random_state=seed, bootstrap=True, **kw)
        elif base == "tree":
            self.model = BaggingClassifier(
                DecisionTreeClassifier(), n_estimators=K,
                random_state=seed, bootstrap=True, **kw)
        else:
            raise ValueError(base)
        self.classes_ = None

    def fit(self, X, y, sample_weight=None):
        self.model.fit(X, y, sample_weight=sample_weight)
        self.classes_ = self.model.classes_
        return self

    def member_proba(self, X) -> np.ndarray:
        X = np.asarray(X, float)
        if self.base == "rf":
            preds = [est.predict_proba(X) for est in self.model.estimators_]
            # align each tree's columns to the forest classes
            preds = [self._align(p, est) for p, est in
                     zip(preds, self.model.estimators_)]
        else:
            preds = []
            for est, feats in zip(self.model.estimators_,
                                  self.model.estimators_features_):
                preds.append(self._align(est.predict_proba(X[:, feats]), est))
        return np.stack(preds, axis=0)  # [K, N, C]

    def _align(self, proba, est):
        C = len(self.classes_)
        if proba.shape[1] == C:
            return proba
        out = np.zeros((proba.shape[0], C))
        for j, c in enumerate(est.classes_):
            out[:, list(self.classes_).index(c)] = proba[:, j]
        return out

    def mean_proba(self, X):
        return self.member_proba(X).mean(axis=0)


class DomainClassifier:
    """pi(x) = P(in-domain). Trained on source-train vs target-pool features."""

    def __init__(self, seed: int = 0):
        self.clf = LogisticRegression(max_iter=1000, random_state=seed)

    def fit(self, Xs, Xt):
        X = np.vstack([Xs, Xt])
        y = np.r_[np.ones(len(Xs)), np.zeros(len(Xt))]  # 1 = in-domain (source)
        self.clf.fit(X, y)
        return self

    def pi(self, X):
        return self.clf.predict_proba(X)[:, 1]
