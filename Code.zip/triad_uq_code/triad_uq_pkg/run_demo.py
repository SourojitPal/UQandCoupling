"""
Self-contained end-to-end smoke test on a SYNTHETIC two-domain problem.
This exercises the full plumbing (ensemble -> grids -> decomposition ->
controls -> H1-H5) without any external download, so you can confirm the code
runs before pointing pipeline.run_pair at the real UCI sites.

The synthetic data here is ONLY a plumbing test -- it is not part of the
reported experiment (Rev.2 plan section 9 / 3.3).

Run:  python run_demo.py
"""
import numpy as np
from sklearn.datasets import make_classification

from triad_uq.models import BaggedEnsemble, DomainClassifier
from triad_uq.interventions import baseline_ensemble, finetune_selftrain, active_learning
from triad_uq.joint_grid import decompose_set
from triad_uq.controls import permute_z_null
from triad_uq.independent_bank import proxy_a_distance, rbf_mmd2
from triad_uq import hypotheses as H


def make_domain(n, shift, seed):
    X, y = make_classification(n_samples=n, n_features=13, n_informative=6,
                               n_redundant=2, random_state=seed, class_sep=1.2)
    X = X + shift                       # covariate shift
    return X.astype(float), y


def main():
    rng = np.random.default_rng(0)
    Xs, ys = make_domain(600, shift=0.0, seed=1)          # source
    Xt, yt = make_domain(400, shift=1.1, seed=2)          # shifted target

    # split target: test / pool / adapt
    idx = rng.permutation(len(Xt))
    te, po, ad = idx[:160], idx[160:320], idx[320:]
    Xt_test = Xt[te]                      # labels not needed on the test split here
    Xt_pool, yt_pool = Xt[po], yt[po]
    Xt_adapt, yt_adapt = Xt[ad], yt[ad]

    K = 25
    src = baseline_ensemble(Xs, ys, K=K, seed=0)
    ft = finetune_selftrain(Xs, ys, Xt_adapt, yt_adapt, Xt_pool=Xt_pool,
                            K=K, seed=0, source_model=src)
    al = active_learning(Xs, ys, Xt_pool, yt_pool, budget=len(yt_adapt), K=K, seed=0)

    dom = DomainClassifier(seed=0).fit(Xs, Xt_pool)
    pi_test = dom.pi(Xt_test)

    def grids(m):
        return np.transpose(m.member_proba(Xt_test), (1, 0, 2))

    P_S = grids(src); P_T_ft = grids(ft); P_T_al = grids(al)

    base_terms = decompose_set(P_S, P_S, pi_test)
    ft_terms = decompose_set(P_S, P_T_ft, pi_test)
    al_terms = decompose_set(P_S, P_T_al, pi_test)

    print("=== closure (correctness gate) ===")
    print(f"  max |residual| finetune : {ft_terms['max_abs_residual']:.2e}")
    print(f"  fraction points clipped : {ft_terms['frac_clipped']:.3f}")

    print("\n=== mean terms on target-test ===")
    for name, tt in [("baseline", base_terms), ("finetune", ft_terms), ("active", al_terms)]:
        print(f"  {name:9s}  Total={tt['total'].mean():.3f}  Ale={tt['aleatoric'].mean():.3f}"
              f"  Epi={tt['epistemic'].mean():.3f}  Dist={tt['distributional'].mean():.3f}"
              f"  Coup={tt['coupling'].mean():.3f}")

    print("\n=== controls (must collapse) ===")
    c = permute_z_null(P_S, P_T_ft, pi_test, seed=0)
    print(f"  permute-Z null: |Dist|={c['distributional_null_mean']:.4f}"
          f"  |Coup|={c['coupling_null_mean']:.4f}   (vs real Dist="
          f"{ft_terms['distributional'].mean():.4f})")

    print("\n=== independent Distributional instruments (route B) ===")
    print(f"  A-distance={proxy_a_distance(Xs, Xt_test):.3f}   MMD^2={rbf_mmd2(Xs, Xt_test):.4f}")

    print("\n=== hypotheses ===")
    print("  H1:", H.h1_regime(ft_terms["coupling"]))
    print("  H2 finetune:", H.h2_specificity(
        ft_terms["distributional"] - base_terms["distributional"],
        ft_terms["epistemic"] - base_terms["epistemic"], arm="finetune"))
    print("  H2 active  :", H.h2_specificity(
        al_terms["distributional"] - base_terms["distributional"],
        al_terms["epistemic"] - base_terms["epistemic"], arm="active"))
    d_epi_cross = al_terms["epistemic"] - base_terms["epistemic"]
    print("  H3 (cross): ", H.h3_coupling_predicts_epistemic(ft_terms["coupling"], d_epi_cross))
    print("\nDemo finished OK.")


if __name__ == "__main__":
    main()
