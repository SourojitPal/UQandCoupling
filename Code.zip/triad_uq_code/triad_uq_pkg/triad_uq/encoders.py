"""
Modality-agnostic feature encoders for TRIAD-UQ.

Turn raw inputs into the numeric [N, D] feature matrices the pipeline consumes,
so the SAME six-term decomposition runs on tabular data, images, or a fused
tabular+image vector. Downstream code never sees the modality.

Image encoding is AUTO (`backbone="auto"`):
  * a pretrained deep backbone (torchvision ResNet, or CLIP if you wire it in)
    when `torch` is importable AND its weights can be obtained, else
  * a torch-free fallback (PIL + numpy): resized-pixel thumbnail + per-channel
    colour histogram, plus a HOG texture descriptor when scikit-image is present.
Both paths return float32 features of a fixed width, so a run never half-fails.

`LAST_IMAGE_ENCODER` records which encoder actually ran (goes into the manifest).
"""
from __future__ import annotations
import numpy as np

LAST_IMAGE_ENCODER: str | None = None

try:
    import skimage  # noqa: F401
    _HAS_SKIMAGE = True
except Exception:
    _HAS_SKIMAGE = False


# ---------------------------------------------------------------------- tabular
def encode_tabular(X) -> np.ndarray:
    """Tabular passthrough -> float32 [N, D] (NaNs preserved; pipeline imputes)."""
    if hasattr(X, "values"):
        X = X.values
    return np.asarray(X, dtype="float32")


# ------------------------------------------------------------------ image: load
def _to_pil_list(images):
    from PIL import Image
    pil = []
    seq = images if not isinstance(images, np.ndarray) else list(images)
    for im in seq:
        if isinstance(im, str):
            p = Image.open(im).convert("RGB")
        elif isinstance(im, np.ndarray):
            a = im
            if a.dtype != np.uint8:
                a = (np.clip(a, 0, 1) * 255).astype("uint8") if a.max() <= 1.0 \
                    else np.clip(a, 0, 255).astype("uint8")
            if a.ndim == 2:
                a = np.stack([a] * 3, axis=-1)
            p = Image.fromarray(a).convert("RGB")
        else:                                  # assume a PIL image
            p = im.convert("RGB")
        pil.append(p)
    return pil


# ---------------------------------------------------------------- image: deep
def _deep_encode(pils, batch: int = 64):
    """torchvision ResNet-18 global-avg-pool features. Raises if unavailable."""
    import torch
    from torchvision import models

    weights = models.ResNet18_Weights.DEFAULT      # may trigger a weight download
    net = models.resnet18(weights=weights)         # raises offline w/o cached weights
    preprocess = weights.transforms()
    net.fc = torch.nn.Identity()
    net.eval()

    feats = []
    with torch.no_grad():
        for i in range(0, len(pils), batch):
            xb = torch.stack([preprocess(p) for p in pils[i:i + batch]])
            feats.append(net(xb).cpu().numpy())
    return np.vstack(feats).astype("float32"), "torchvision/resnet18(pretrained)"


# ---------------------------------------------------------------- image: light
def _light_encode(pils, image_size: int = 48):
    """Torch-free features: 8x8 RGB thumbnail + colour histogram (+ HOG)."""
    feats = []
    hog = rgb2gray = None
    if _HAS_SKIMAGE:
        from skimage.feature import hog as _hog
        from skimage.color import rgb2gray as _rgb2gray
        hog, rgb2gray = _hog, _rgb2gray
    for p in pils:
        arr = np.asarray(p.resize((image_size, image_size)), dtype="float32") / 255.0
        thumb = (np.asarray(p.resize((8, 8)), dtype="float32") / 255.0).ravel()  # 192
        hist = np.concatenate([
            np.histogram(arr[:, :, c], bins=16, range=(0, 1), density=True)[0]
            for c in range(3)]).astype("float32")                                # 48
        parts = [thumb, hist]
        if hog is not None:
            cell = max(1, image_size // 4)
            hv = hog(rgb2gray(arr), orientations=8,
                     pixels_per_cell=(cell, cell),
                     cells_per_block=(1, 1), feature_vector=True)
            parts.append(hv.astype("float32"))
        feats.append(np.concatenate(parts))
    name = "light/thumbnail+colorhist" + ("+hog" if hog is not None else "")
    return np.vstack(feats).astype("float32"), name


def encode_images(images, backbone: str = "auto", image_size: int = 48,
                  verbose: bool = True) -> np.ndarray:
    """
    Encode images -> float32 [N, D].

    images   : list of file paths / PIL images / ndarrays, or an ndarray
               [N,H,W,3] or [N,H,W].
    backbone : "auto" (deep if torch+weights available, else light-fallback),
               "deep" (force deep; raises if unavailable),
               "light" (force the torch-free encoder).
    """
    global LAST_IMAGE_ENCODER
    pils = _to_pil_list(images)

    if backbone in ("auto", "deep"):
        try:
            import torch  # noqa: F401
            emb, name = _deep_encode(pils)
            LAST_IMAGE_ENCODER = name
            if verbose:
                print(f"[encoders] image encoder: {name}  D={emb.shape[1]}")
            return emb
        except Exception as e:
            if backbone == "deep":
                raise
            if verbose:
                print(f"[encoders] deep encoder unavailable ({str(e)[:70]}); "
                      f"using torch-free fallback.")

    emb, name = _light_encode(pils, image_size=image_size)
    LAST_IMAGE_ENCODER = name
    if verbose:
        print(f"[encoders] image encoder: {name}  D={emb.shape[1]}")
    return emb


# ------------------------------------------------------------------------ fuse
def fuse(*blocks, zscore: bool = False) -> np.ndarray:
    """
    Concatenate feature blocks column-wise into one [N, sum(D)] matrix.
    For pipeline use keep zscore=False and let split_pair's StandardScaler (fit
    on source-train only) handle scaling -- that keeps the split leakage-free.
    Set zscore=True only for standalone/exploratory use.
    """
    mats = [np.asarray(b, dtype="float32") for b in blocks]
    n = mats[0].shape[0]
    assert all(m.shape[0] == n for m in mats), "all blocks must share N rows"
    if zscore:
        z = []
        for m in mats:
            mu = np.nanmean(m, axis=0)
            sd = np.nanstd(m, axis=0); sd[sd == 0] = 1.0
            z.append((m - mu) / sd)
        mats = z
    return np.hstack(mats).astype("float32")
