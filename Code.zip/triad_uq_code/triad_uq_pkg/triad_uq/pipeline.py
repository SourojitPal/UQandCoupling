"""
Pipeline orchestration for one real source->target pair (Rev.2 plan sections
5, 6, 11). Produces the per-point long table every report reads from, plus the
control and hypothesis summaries.

Usage (on a machine with the UCI data available):

    from triad_uq.data import load_sites, split_pair
    from triad_uq.pipeline import run_pair
    sites = load_sites(data_dir="data/")
    res = run_pair(sites["cleveland"], sites["hungarian"], seed=0)
"""
from __future__ import annotations
import numpy as np
import pandas as pd

from .data import split_pair, Site
from .models import DomainClassifier
from .interventions import baseline_ensemble, finetune_selftrain, active_learning
from .joint_grid import decompose_set
from .independent_bank import proxy_a_distance, rbf_mmd2, domain_mi_nats
from .controls import permute_z_null
from . import hypotheses as H


def _grids(src_model, tgt_model, X):
    """member_proba grids [N,K,C] for source and target-adapted ensembles."""
    P_S = np.transpose(src_model.member_proba(X), (1, 0, 2))  # [N,K,C]
    P_T = np.transpose(tgt_model.member_proba(X), (1, 0, 2))
    return P_S, P_T


def run_pair(src: Site, tgt: Site, base="rf", K=25, seed=0,
             pair_name="src->tgt") -> dict:
    sp = split_pair(src, tgt, seed=seed)

    # --- models ---
    src_model = baseline_ensemble(sp.Xs_train, sp.ys_train, base=base, K=K, seed=seed)
    ft_model = finetune_selftrain(sp.Xs_train, sp.ys_train, sp.Xt_adapt, sp.yt_adapt,
                                  Xt_pool=sp.Xt_pool, base=base, K=K, seed=seed,
                                  source_model=src_model)
    al_model = active_learning(sp.Xs_train, sp.ys_train, sp.Xt_pool, sp.yt_pool,
                               budget=len(sp.yt_adapt), base=base, K=K, seed=seed)

    dom = DomainClassifier(seed=seed).fit(sp.Xs_train, sp.Xt_pool)
    pi_test = dom.pi(sp.Xt_test)

    # --- decompositions on TARGET-TEST (the only place terms are reported) ---
    P_S, P_T_ft = _grids(src_model, ft_model, sp.Xt_test)
    _, P_T_al = _grids(src_model, al_model, sp.Xt_test)

    base_terms = decompose_set(P_S, P_S, pi_test)          # baseline: S vs S
    ft_terms = decompose_set(P_S, P_T_ft, pi_test)         # fine-tune S vs T
    al_terms = decompose_set(P_S, P_T_al, pi_test)         # active   S vs T

    # --- controls (report first) ---
    ctrl_permute = permute_z_null(P_S, P_T_ft, pi_test, seed=seed)

    # --- independent instruments for Distributional (route B) ---
    a_dist = proxy_a_distance(sp.Xs_train, sp.Xt_test, seed=seed)
    mmd = rbf_mmd2(sp.Xs_train, sp.Xt_test)
    dist_direct_nats = domain_mi_nats(sp.Xs_train, sp.Xt_pool,
                                      sp.Xt_test, sp.yt_test)

    # --- hypotheses ---
    h1 = H.h1_regime(ft_terms["coupling"])
    h2_ft = H.h2_specificity(ft_terms["distributional"] - base_terms["distributional"],
                             ft_terms["epistemic"] - base_terms["epistemic"], arm="finetune")
    h2_al = H.h2_specificity(al_terms["distributional"] - base_terms["distributional"],
                             al_terms["epistemic"] - base_terms["epistemic"], arm="active")
    # H3 cross-intervention: baseline Coupling (from FT grid at baseline is S vs S = 0),
    # so use fine-tune Coupling as the baseline-regime signal vs active-learning dEpistemic
    d_epi_cross = al_terms["epistemic"] - base_terms["epistemic"]
    h3 = H.h3_coupling_predicts_epistemic(ft_terms["coupling"], d_epi_cross, seed=seed)
    d_atoms_ft = {k: ft_terms[k] - base_terms[k]
                  for k in ["aleatoric", "unique_theta", "unique_z", "redundancy", "synergy"]}
    h4_ft = H.h4_diagnostic(d_atoms_ft, arm="finetune")
    # H5: recover Distributional from the identity vs the nats-scale independent instrument
    recovered_dist = (ft_terms["total"] - ft_terms["aleatoric"]
                      - ft_terms["epistemic"] + ft_terms["coupling"])
    h5 = H.h5_recovery(np.full_like(recovered_dist, dist_direct_nats), recovered_dist)

    # --- long table ---
    rows = []
    for stage, terms in [("baseline", base_terms), ("finetune", ft_terms),
                         ("active", al_terms)]:
        for i in range(len(terms["total"])):
            for term in ["total", "aleatoric", "epistemic", "distributional",
                         "coupling", "unique_theta", "unique_z", "redundancy", "synergy"]:
                rows.append((pair_name, stage, i, term, terms[term][i], pi_test[i]))
    long_df = pd.DataFrame(rows, columns=["pair", "stage", "point_id",
                                          "term", "value", "pi"])

    return {
        "pair": pair_name, "features": sp.features,
        "closure_max_residual": ft_terms["max_abs_residual"],
        "controls": ctrl_permute,
        "distributional_instruments": {"a_distance": a_dist, "mmd2": mmd,
                                       "nats_direct": dist_direct_nats},
        "H1": h1, "H2_finetune": h2_ft, "H2_active": h2_al,
        "H3": h3, "H4_finetune": h4_ft, "H5": h5,
        "long_table": long_df,
    }
