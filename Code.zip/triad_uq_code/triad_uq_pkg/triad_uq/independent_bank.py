"""
Independent estimator bank -- route-B instruments that do NOT read the joint
grid (Rev.2 plan section 3.1). These are what convert the identity from a
tautology into a testable relationship.

Independence is graded honestly:
  Distributional : STRONG  (MMD / A-distance / nats domain-MI -- no model preds)
  Epistemic      : WEAK    (predictive variance -- same members, different functional)
  Aleatoric      : MODERATE (kNN feature-space label disagreement)
Only Distributional has a genuinely model-free channel; it is the anchor of
the LOTO recovery test (H5).
"""
from __future__ import annotations
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_predict
from sklearn.neighbors import NearestNeighbors


# ---------------------------------------------------------------- Distributional
def rbf_mmd2(X: np.ndarray, Y: np.ndarray, gamma: float | None = None) -> float:
    """Biased RBF-kernel MMD^2 between feature sets X and Y (theta-free)."""
    X = np.asarray(X, float); Y = np.asarray(Y, float)
    if gamma is None:
        Z = np.vstack([X, Y])
        d2 = np.sum((Z[:, None, :] - Z[None, :, :]) ** 2, axis=-1)
        med = np.median(d2[d2 > 0]) if np.any(d2 > 0) else 1.0
        gamma = 1.0 / (med + 1e-12)

    def k(A, B):
        d2 = np.sum((A[:, None, :] - B[None, :, :]) ** 2, axis=-1)
        return np.exp(-gamma * d2)

    return float(k(X, X).mean() + k(Y, Y).mean() - 2.0 * k(X, Y).mean())


def mmd2_permutation_pvalue(X, Y, n_perm=200, seed=0):
    """Permutation p-value for MMD^2 (null: X, Y from same distribution)."""
    rng = np.random.default_rng(seed)
    obs = rbf_mmd2(X, Y)
    Z = np.vstack([X, Y]); n = len(X)
    count = 0
    for _ in range(n_perm):
        idx = rng.permutation(len(Z))
        if rbf_mmd2(Z[idx[:n]], Z[idx[n:]]) >= obs:
            count += 1
    return obs, (count + 1) / (n_perm + 1)


def proxy_a_distance(Xs: np.ndarray, Xt: np.ndarray, cv: int = 5, seed: int = 0) -> float:
    """
    Proxy A-distance = 2(1 - 2*err) from a source-vs-target domain classifier
    (empirical d_HdeltaH). theta-free. Returns a value in [0, 2].
    """
    X = np.vstack([Xs, Xt])
    y = np.r_[np.zeros(len(Xs)), np.ones(len(Xt))]
    clf = LogisticRegression(max_iter=1000)
    pred = cross_val_predict(clf, X, y, cv=cv)
    err = float(np.mean(pred != y))
    return 2.0 * (1.0 - 2.0 * err)


def domain_mi_nats(Xs: np.ndarray, Xt: np.ndarray, Xtest: np.ndarray,
                   ytest: np.ndarray, cv: int = 5) -> float:
    """
    Nats-scale, theta-free estimate of Distributional = I(y; Z) on the target
    test set: fit a probabilistic domain classifier for pi(x)=P(Z=1|x), then
    estimate I(y;Z) from the empirical joint of (y_test, Zhat) where Zhat is
    sampled/soft-assigned by pi. This is the independent instrument that the
    LOTO recovery of Distributional (H5) is checked against.
    """
    from .info import mi_from_joint2
    Xd = np.vstack([Xs, Xt])
    yd = np.r_[np.zeros(len(Xs)), np.ones(len(Xt))]
    clf = LogisticRegression(max_iter=1000).fit(Xd, yd)
    pi_test = clf.predict_proba(Xtest)[:, 1]          # P(Z=1|x) on test points

    classes = np.unique(ytest)
    C = len(classes)
    joint = np.zeros((C, 2))
    for c_idx, c in enumerate(classes):
        m = ytest == c
        # soft-assign each point's mass to Z=0 / Z=1 by (1-pi, pi)
        joint[c_idx, 0] += np.sum(1.0 - pi_test[m])
        joint[c_idx, 1] += np.sum(pi_test[m])
    joint /= joint.sum()
    return mi_from_joint2(joint)


# ---------------------------------------------------------------- Epistemic
def predictive_variance(P_members: np.ndarray) -> np.ndarray:
    """
    Route-B epistemic proxy: variance across members of P(y=1) for binary tasks
    (or mean per-class variance for multiclass). P_members: [N, K, C] -> [N].
    Different functional of the SAME members => rank/sign cross-check only.
    """
    P = np.asarray(P_members, float)
    return P.var(axis=1).mean(axis=-1)


# ---------------------------------------------------------------- Aleatoric
def knn_label_disagreement(X: np.ndarray, y: np.ndarray, Xq: np.ndarray,
                           k: int = 10) -> np.ndarray:
    """
    Route-B aleatoric proxy: local label disagreement among k feature-space
    neighbours (irreducible-noise floor). Needs labels on the reference set.
    Returns [len(Xq)].
    """
    nn = NearestNeighbors(n_neighbors=k).fit(X)
    idx = nn.kneighbors(Xq, return_distance=False)
    out = np.zeros(len(Xq))
    for i, nb in enumerate(idx):
        labels = y[nb]
        p1 = labels.mean()
        out[i] = 1.0 - max(p1, 1.0 - p1)   # 0 = pure, 0.5 = maximally mixed
    return out
