"""
Synthetic joints with KNOWN ground truth, for estimator validation only
(Rev.2 plan section 9). These validate the estimator, never the healthcare
data, and are never reported as findings.

Each function returns a joint P(y, s1, s2) that `info.decompose_from_joint`
can consume directly.
"""
from __future__ import annotations
import numpy as np


def joint_redundant() -> np.ndarray:
    """y = s1 = s2, fair coin. Expect Coupling > 0, Synergy = 0 (redundancy)."""
    P = np.zeros((2, 2, 2))
    for v in (0, 1):
        P[v, v, v] = 0.5
    return P


def joint_xor() -> np.ndarray:
    """s1, s2 independent fair bits; y = s1 XOR s2. Expect Coupling < 0 (synergy)."""
    P = np.zeros((2, 2, 2))
    for s1 in (0, 1):
        for s2 in (0, 1):
            P[s1 ^ s2, s1, s2] = 0.25
    return P


def joint_unique_theta() -> np.ndarray:
    """y = s1; s2 independent noise. Expect Unique_theta > 0, others ~0."""
    P = np.zeros((2, 2, 2))
    for s1 in (0, 1):
        for s2 in (0, 1):
            P[s1, s1, s2] = 0.25
    return P


def joint_independent() -> np.ndarray:
    """y independent of both sources. Expect all information terms ~0."""
    P = np.full((2, 2, 2), 1.0 / 8.0)
    return P
