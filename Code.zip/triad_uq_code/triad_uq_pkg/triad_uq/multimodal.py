"""
Multimodal support for TRIAD-UQ: build pipeline-ready `Site` objects from
tabular data, images, or a fused tabular+image vector, plus a small PAIRED
synthetic dataset so the whole multimodal path runs offline at one go.

The synthetic data here is PLUMBING ONLY (like run_demo / the synthetic site
fallback) -- never a reported result. Swap `synth_multimodal` for your own
paired image+tabular loader to make it real; `build_sites` is unchanged.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

from .data import Site, FEATURES
from . import encoders as E

# per-site (covariate shift, RGB tint) -- shift is the site boundary
_SPECS = {
    "cleveland":   (0.0, (220, 80, 80)),
    "hungarian":   (0.6, (80, 180, 80)),
    "switzerland": (1.0, (80, 80, 200)),
    "va":          (0.8, (200, 180, 60)),
}


def _make_site(name: str, F: np.ndarray, y, prefix: str = "f") -> Site:
    cols = [f"{prefix}{i}" for i in range(F.shape[1])]
    return Site(name, pd.DataFrame(np.asarray(F, dtype="float32"), columns=cols),
                np.asarray(y))


def _gen_images(rng, y, image_size: int, tint, shift: float) -> np.ndarray:
    """Class-dependent shape (disc vs diamond) + per-site tint/brightness/noise."""
    S = image_size
    imgs = np.zeros((len(y), S, S, 3), dtype="uint8")
    xx, yy = np.meshgrid(np.linspace(-1, 1, S), np.linspace(-1, 1, S))
    disc = (xx ** 2 + yy ** 2) < 0.5
    diamond = (np.abs(xx) + np.abs(yy)) < 0.7
    for i, c in enumerate(y):
        mask = disc if c == 0 else diamond
        base = np.zeros((S, S, 3), dtype="float32")
        for ch in range(3):
            base[:, :, ch] = mask * (tint[ch] / 255.0)
        base = base * (0.7 + 0.3 * shift) + rng.normal(0, 0.05 + 0.03 * shift, (S, S, 3))
        base += 0.15 * shift                                  # site brightness offset
        imgs[i] = np.clip(base * 255.0, 0, 255).astype("uint8")
    return imgs


def synth_multimodal(seed: int = 0, n_per_site: int = 120,
                     image_size: int = 48) -> dict:
    """Return {site: {"tab": DataFrame[FEATURES], "img": uint8[n,S,S,3], "y": [n]}}."""
    out = {}
    for off, (name, (shift, tint)) in enumerate(_SPECS.items()):
        r = np.random.default_rng(seed + 101 * (off + 1))
        Xc = r.normal(shift, 1.0, size=(n_per_site, len(FEATURES)))
        logit = 0.8 * Xc[:, 0] - 0.6 * Xc[:, 3] + 0.5 * Xc[:, 7] + r.normal(0, 1, n_per_site)
        y = (logit > np.median(logit)).astype(int)
        tab = pd.DataFrame(Xc, columns=FEATURES)
        for c in ("ca", "thal", "slope"):
            tab.loc[r.random(n_per_site) < 0.10, c] = np.nan
        out[name] = {"tab": tab, "img": _gen_images(r, y, image_size, tint, shift),
                     "y": y}
    return out


def build_sites(raw: dict, modality: str, encoder_kwargs: dict | None = None,
                verbose: bool = True) -> dict:
    """
    Build {site: Site} for one modality from a raw dict (as `synth_multimodal`
    returns, or your own paired loader).

    modality : "tabular" | "image" | "fused".
    """
    encoder_kwargs = encoder_kwargs or {}
    sites = {}
    say = verbose
    for name, d in raw.items():
        if modality == "tabular":
            F, pref = E.encode_tabular(d["tab"]), "t"
        elif modality == "image":
            F, pref = E.encode_images(d["img"], verbose=say, **encoder_kwargs), "i"
        elif modality == "fused":
            Ft = E.encode_tabular(d["tab"])
            Fi = E.encode_images(d["img"], verbose=say, **encoder_kwargs)
            F, pref = E.fuse(Ft, Fi), "m"
        else:
            raise ValueError(f"unknown modality: {modality}")
        sites[name] = _make_site(name, F, d["y"], prefix=pref)
        say = False                                   # print the encoder line once
    return sites


def save_image_montage(raw: dict, path: str, per_site: int = 6, seed: int = 0,
                       title: str = "Example images (per domain)"):
    """Save a grid of example images (rows = domains/sites, cols = samples)."""
    import matplotlib.pyplot as plt
    from . import plotstyle; plotstyle.apply_style()
    rng = np.random.default_rng(seed)
    names = list(raw)
    fig, axes = plt.subplots(len(names), per_site,
                             figsize=(1.5 * per_site, 1.5 * len(names)), squeeze=False)
    for r, name in enumerate(names):
        imgs, y = raw[name]["img"], raw[name]["y"]
        idx = rng.choice(len(imgs), size=min(per_site, len(imgs)), replace=False)
        for c, k in enumerate(idx):
            ax = axes[r][c]
            ax.imshow(imgs[k]); ax.set_xticks([]); ax.set_yticks([])
            if c == 0:
                ax.set_ylabel(name, fontsize=12)
            ax.set_title(f"cls {int(y[k])}", fontsize=11)
    fig.suptitle(title, fontsize=14)
    fig.tight_layout()
    base = path[:-4] if path.lower().endswith((".png", ".pdf")) else path
    plotstyle.save_vector(fig, base)               # PNG (300 dpi) + vector PDF
    return fig
